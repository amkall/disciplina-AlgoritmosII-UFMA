#include<iostream>
using namespace std;

typedef struct _tabuleiro_{
    int *dx;
    int *dy;
    int num; //numero de linhas / colunas
    int numSqr; //n�mero total de casas
    int **table;
}tabuleiro;


tabuleiro* Inicializar(int col){
    tabuleiro *novo = new tabuleiro[0];

    novo->dx      = new int[col];
    novo->dy      = new int[col];
    novo->num     = col;
    novo->numSqr  = col * col; //� uma matriz quadrada
    novo->table   = new int*[col];

    for(int i = 0;i < col; i++){
        novo->table[i] = new int[col];
    }

    //sentinela na matriz
    for(int i = 0; i < col ; i++){
        for(int j = 0; j < col ; j++){
            novo->table[i][j] = 0;
        }
    }
    return novo;
}

bool Accept(int x, int y, tabuleiro *tab){
    //verifica se a posi��o esta na tabela
    bool result = ((x >= 0) && (x <= tab->num - 1));
    result = result && ((y >= 0) && (y <= tab->num - 1));

    //verifica se a posi��o ja foi preenchida
    result = result && (tab->table[x][y] == 0);

    return result;
}

bool tryMov(int i, int x, int y, tabuleiro *tab){

    bool done = (i > tab->numSqr);
    int k = 0, u, v;

    while((!done) && (k < 8)){
      //coordenadas dos 8 movimentos possiveis em volta do cavalo
      u = x + tab->dx[k];
      v = y + tab->dy[k];
      //verifica se o movimento para a posi��o (u, v) � valido
      if (Accept(u, v, tab)) {

         tab->table[u][v] = i;
         done = tryMov(i + 1, u, v, tab); //tenta outro movimento

         if (!done) {
            tab->table[u][v] = 0; //sem sucesso. Descarta movimento
         }
      }
      k = k + 1; //passa ao pr�ximo movimento poss�vel dentre os 8
   }
   return done;
}
void PrintarTabuleiro(int x, int y, tabuleiro *tab){
    tab->table[x][y] = 1;
    //busca solu��o do passeio
    bool done = tryMov(2, x, y, tab);

    //printa a matriz solu��o
    if (done) {
       for (int i = 0; i < tab->num; i++) {
           for (int j = 0; j < tab->num; j++) {
                if (tab->table[i][j] < 10)cout<<tab->table[i][j]<<"  ";
                else cout<<tab->table[i][j]<<" ";
           }
           cout<<"\n";
       }
    } else {
           cout<<"Nao ha passeio possivel";
    }

}
int main(){
    //posi��es possiveis a partir de uma referencia
    int dx[8] = {2,1,-1,-2,-2,-1,1,2};
    int dy[8] = {1,2,2,1,-1,-2,-2,-1};

    //numero de linhas X colunas   col X col matriz quadrada
    int col;
    cout<<"uma matriz NxN sera criada, a seguir voce devera informar o valor de N"<<"\n";
    cout<< "informe qual o tamanho do tabuleiro (recomendado 8)"<<"\n";
    cin >> col;

    tabuleiro *tab = Inicializar(col);
    tab->dx = dx;
    tab->dy = dy;


    //posi��o inicial do cavalo (0,0)
    PrintarTabuleiro(0, 0, tab);

}
